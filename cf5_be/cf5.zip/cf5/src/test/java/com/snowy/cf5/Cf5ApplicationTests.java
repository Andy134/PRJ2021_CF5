package com.snowy.cf5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cf5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
